# Phaser_3_pong

This is my remake of pong I made using Phaser.js! 
It currently does not run the best but I will do some slight updates in the future!
It is local multiplayer for the moment.

The controls for the player on the left side of the screen are: W to go up and S to go down.
The controls for the player on the right side of the screen are: Up arrow key and down arrow key.

Current known Bugs:


If you find anymore bugs during use of the game please tell me!
